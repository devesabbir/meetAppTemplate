let localStream;
let peerConnection;
let remoteStream;

let servers = {
    iceServers: [{
        urls: ['stun:stun1.1.google.com:19302',
            'stun:stun2.1.google.com:19302'
        ]
    }]

}

//  Local Stream Init 
const localStreamInit = async () => {
    localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false
    })
    document.getElementById('screenTwo').srcObject = localStream
}

localStreamInit()


//  Create Offer 
const createOffer = async () => {

    peerConnection = new RTCPeerConnection(servers)

    let offer = await peerConnection.createOffer()
    peerConnection.setLocalDescription(offer)

    peerConnection.onicecandidate = async (event) => {
        if (event.candidate) {
            document.querySelector('#offerSdp').value = JSON.stringify(peerConnection.localDescription)
        }
    }

    remoteStream = new MediaStream()

    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream)
    });

    peerConnection.ontrack = (e) => {
        e.streams[0].getTracks().forEach(track => {
             remoteStream.addTrack(track)
        })

    }


}

document.querySelector('#createOffer').onclick = () => {
    createOffer()
}



//  Camera Control
let cameraStatus = true
cameraStatus && document.querySelector('#camBtn').classList.add('active')
document.querySelector('#camBtn').onclick = (e) => {
    cameraStatus = !cameraStatus
    localStream.getVideoTracks()[0].enabled = cameraStatus
    document.querySelector('#camBtn').classList.toggle('active')


}

//  Camera Control
let micStatus = true
micStatus && document.querySelector('#micBtn').classList.add('active')
document.querySelector('#micBtn').onclick = (e) => {
    micStatus = !micStatus
    localStream.getAudioTracks()[0].enabled = micStatus
    document.querySelector('#micBtn').classList.toggle('active')


}